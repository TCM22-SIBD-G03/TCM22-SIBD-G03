import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {Formacao} from '../models';
import {FormacaoRepository} from '../repositories';

export class FormacaoController {
  constructor(
    @repository(FormacaoRepository)
    public formacaoRepository : FormacaoRepository,
  ) {}

  @post('/formacaos')
  @response(200, {
    description: 'Formacao model instance',
    content: {'application/json': {schema: getModelSchemaRef(Formacao)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Formacao, {
            title: 'NewFormacao',
            exclude: ['id'],
          }),
        },
      },
    })
    formacao: Omit<Formacao, 'id'>,
  ): Promise<Formacao> {
    return this.formacaoRepository.create(formacao);
  }

  @get('/formacaos/count')
  @response(200, {
    description: 'Formacao model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Formacao) where?: Where<Formacao>,
  ): Promise<Count> {
    return this.formacaoRepository.count(where);
  }

  @get('/formacaos')
  @response(200, {
    description: 'Array of Formacao model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Formacao, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Formacao) filter?: Filter<Formacao>,
  ): Promise<Formacao[]> {
    return this.formacaoRepository.find(filter);
  }

  @patch('/formacaos')
  @response(200, {
    description: 'Formacao PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Formacao, {partial: true}),
        },
      },
    })
    formacao: Formacao,
    @param.where(Formacao) where?: Where<Formacao>,
  ): Promise<Count> {
    return this.formacaoRepository.updateAll(formacao, where);
  }

  @get('/formacaos/{id}')
  @response(200, {
    description: 'Formacao model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Formacao, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Formacao, {exclude: 'where'}) filter?: FilterExcludingWhere<Formacao>
  ): Promise<Formacao> {
    return this.formacaoRepository.findById(id, filter);
  }

  @patch('/formacaos/{id}')
  @response(204, {
    description: 'Formacao PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Formacao, {partial: true}),
        },
      },
    })
    formacao: Formacao,
  ): Promise<void> {
    await this.formacaoRepository.updateById(id, formacao);
  }

  @put('/formacaos/{id}')
  @response(204, {
    description: 'Formacao PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() formacao: Formacao,
  ): Promise<void> {
    await this.formacaoRepository.replaceById(id, formacao);
  }

  @del('/formacaos/{id}')
  @response(204, {
    description: 'Formacao DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.formacaoRepository.deleteById(id);
  }
}
