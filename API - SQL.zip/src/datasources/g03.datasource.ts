import {inject, lifeCycleObserver, LifeCycleObserver} from '@loopback/core';
import {juggler} from '@loopback/repository';

const config = {
  name: 'g03',
  connector: 'mysql',
  host: 'localhost',
  port: 3306,
  user: 'root',
  password: '',
  database: 'g03',
  file: 'g03.sql' // caminho para o arquivo g03.sql
};

@lifeCycleObserver('datasource')
export class G03DataSource extends juggler.DataSource
  implements LifeCycleObserver {
  static dataSourceName = 'g03';
  static readonly defaultConfig = config;

  constructor(
    @inject('datasources.config.g03', {optional: true})
    dsConfig: object = config,
  ) {
    super(dsConfig);
  }
}
