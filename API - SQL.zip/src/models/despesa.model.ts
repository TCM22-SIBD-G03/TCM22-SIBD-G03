import {Entity, belongsTo, model, property} from '@loopback/repository';
import {Clientes} from './clientes.model';

@model()
export class Despesa extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'number',
    required: true,
  })
  idcliente: number;

  @property({
    type: 'number',
    required: true,
  })
  valor: number;

  @property({
    type: 'date',
    required: true,
  })
  data: string;

  @property({
    type: 'string',
    required: true,
  })
  descricao: string;

  @belongsTo(() => Clientes)
  clienteId: number;

  constructor(data?: Partial<Despesa>) {
    super(data);
  }
}

export interface DespesaRelations {
  // define relationships here
}

export type DespesaWithRelations = Despesa & DespesaRelations;
