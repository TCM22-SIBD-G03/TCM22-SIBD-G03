import {Entity, model, property} from '@loopback/repository';

@model()
export class Estoque extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  estoque_id?: number;

  @property({
    type: 'number',
    required: true,
  })
  quantidade: number;

  constructor(data?: Partial<Estoque>) {
    super(data);
  }
}

export interface EstoqueRelations {
  // defina as relações aqui
}

export type EstoqueWithRelations = Estoque & EstoqueRelations;
