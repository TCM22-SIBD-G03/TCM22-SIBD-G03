import {Entity, model, property} from '@loopback/repository';

@model()
export class Formacao extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
    required: true,
  })
  nome: string;

  @property({
    type: 'string',
  })
  descrição?: string;

  @property({
    type: 'date',
    required: true,
  })
  data: string;

  @property({
    type: 'number',
    required: true,
  })
  duração: number;

  @property({
    type: 'string',
  })
  instrutor?: string;

  constructor(data?: Partial<Formacao>) {
    super(data);
  }
}

export interface FormacaoRelations {
  // define relationships here
}

export type FormacaoWithRelations = Formacao & FormacaoRelations;
