import {Entity, model, property} from '@loopback/repository';

@model()
export class Produto extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  produto_id?: number;

  @property({
    type: 'string',
    required: true,
  })
  nome: string;

  @property({
    type: 'number',
    required: true,
  })
  preco: number;

  @property({
    type: 'number',
  })
  estoque_id?: number;

  @property({
    type: 'string',
  })
  descricao?: string;

  constructor(data?: Partial<Produto>) {
    super(data);
  }
}

export interface ProdutoRelations {
  // define relationships here
}

export type ProdutoWithRelations = Produto & ProdutoRelations;
