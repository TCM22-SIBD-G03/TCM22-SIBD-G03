import {Entity, model, property} from '@loopback/repository';

@model()
export class Seccao extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
    required: true,
  })
  nome: string;

  @property({
    type: 'string',
  })
  descricao?: string;

  @property({
    type: 'number',
  })
  gerente_id?: number;

  constructor(data?: Partial<Seccao>) {
    super(data);
  }
}

export interface SeccaoRelations {
  // define relationships here
}

export type SeccaoWithRelations = Seccao & SeccaoRelations;
