import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {G03DataSource} from '../datasources';
import {Estoque, EstoqueRelations} from '../models';

export class EstoqueRepository extends DefaultCrudRepository<
  Estoque,
  typeof Estoque.prototype.estoque_id, // Atualize para o tipo correto da chave primária
  EstoqueRelations
> {
  constructor(
    @inject('datasources.g03') dataSource: G03DataSource,
  ) {
    super(Estoque, dataSource);
  }
}
