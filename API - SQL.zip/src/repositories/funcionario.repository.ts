import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {G03DataSource} from '../datasources';
import {Funcionario, FuncionarioRelations} from '../models';

export class FuncionarioRepository extends DefaultCrudRepository<
  Funcionario,
  typeof Funcionario.prototype.id,
  FuncionarioRelations
> {
  constructor(
    @inject('datasources.g03') dataSource: G03DataSource,
  ) {
    super(Funcionario, dataSource);
  }
}
