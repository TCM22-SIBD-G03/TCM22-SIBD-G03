export * from './clientes.repository';
export * from './despesa.repository';
export * from './estoque.repository';
export * from './formacao.repository';
export * from './fornecedor.repository';
export * from './funcionario.repository';
export * from './produto.repository';
export * from './seccao.repository';
