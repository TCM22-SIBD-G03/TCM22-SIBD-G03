import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {G03DataSource} from '../datasources';
import {Produto, ProdutoRelations} from '../models';

export class ProdutoRepository extends DefaultCrudRepository<
  Produto,
  typeof Produto.prototype.produto_id,
  ProdutoRelations
> {
  constructor(
    @inject('datasources.g03') dataSource: G03DataSource,
  ) {
    super(Produto, dataSource);
  }
}
