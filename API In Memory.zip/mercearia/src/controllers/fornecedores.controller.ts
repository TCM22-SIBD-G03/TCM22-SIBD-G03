import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {Fornecedores} from '../models';
import {FornecedoresRepository} from '../repositories';

export class FornecedoresController {
  constructor(
    @repository(FornecedoresRepository)
    public fornecedoresRepository : FornecedoresRepository,
  ) {}

  @post('/fornecedores')
  @response(200, {
    description: 'Fornecedores model instance',
    content: {'application/json': {schema: getModelSchemaRef(Fornecedores)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Fornecedores, {
            title: 'NewFornecedores',
            exclude: ['id'],
          }),
        },
      },
    })
    fornecedores: Omit<Fornecedores, 'id'>,
  ): Promise<Fornecedores> {
    return this.fornecedoresRepository.create(fornecedores);
  }

  @get('/fornecedores/count')
  @response(200, {
    description: 'Fornecedores model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Fornecedores) where?: Where<Fornecedores>,
  ): Promise<Count> {
    return this.fornecedoresRepository.count(where);
  }

  @get('/fornecedores')
  @response(200, {
    description: 'Array of Fornecedores model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Fornecedores, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Fornecedores) filter?: Filter<Fornecedores>,
  ): Promise<Fornecedores[]> {
    return this.fornecedoresRepository.find(filter);
  }

  @patch('/fornecedores')
  @response(200, {
    description: 'Fornecedores PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Fornecedores, {partial: true}),
        },
      },
    })
    fornecedores: Fornecedores,
    @param.where(Fornecedores) where?: Where<Fornecedores>,
  ): Promise<Count> {
    return this.fornecedoresRepository.updateAll(fornecedores, where);
  }

  @get('/fornecedores/{id}')
  @response(200, {
    description: 'Fornecedores model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Fornecedores, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Fornecedores, {exclude: 'where'}) filter?: FilterExcludingWhere<Fornecedores>
  ): Promise<Fornecedores> {
    return this.fornecedoresRepository.findById(id, filter);
  }

  @patch('/fornecedores/{id}')
  @response(204, {
    description: 'Fornecedores PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Fornecedores, {partial: true}),
        },
      },
    })
    fornecedores: Fornecedores,
  ): Promise<void> {
    await this.fornecedoresRepository.updateById(id, fornecedores);
  }

  @put('/fornecedores/{id}')
  @response(204, {
    description: 'Fornecedores PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() fornecedores: Fornecedores,
  ): Promise<void> {
    await this.fornecedoresRepository.replaceById(id, fornecedores);
  }

  @del('/fornecedores/{id}')
  @response(204, {
    description: 'Fornecedores DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.fornecedoresRepository.deleteById(id);
  }
}
