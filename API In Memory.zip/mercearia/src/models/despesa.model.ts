import {Entity, model, property} from '@loopback/repository';

@model()
export class Despesa extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'number',
    required: true,
  })
  idcliente: number;

  @property({
    type: 'number',
    required: true,
  })
  valor: number;

  @property({
    type: 'date',
    required: true,
  })
  data: string;

  @property({
    type: 'string',
    required: true,
  })
  descricao: string;


  constructor(data?: Partial<Despesa>) {
    super(data);
  }
}

export interface DespesaRelations {
  // describe navigational properties here
}

export type DespesaWithRelations = Despesa & DespesaRelations;
