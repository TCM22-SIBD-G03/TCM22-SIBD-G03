import {Entity, model, property} from '@loopback/repository';

@model()
export class Estoque extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'number',
    required: true,
  })
  produto_id: number;

  @property({
    type: 'number',
    required: true,
  })
  quantidade: number;


  constructor(data?: Partial<Estoque>) {
    super(data);
  }
}

export interface EstoqueRelations {
  // describe navigational properties here
}

export type EstoqueWithRelations = Estoque & EstoqueRelations;
