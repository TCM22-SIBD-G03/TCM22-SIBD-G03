import {Entity, model, property} from '@loopback/repository';

@model()
export class Fornecedores extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
    required: true,
  })
  nome: string;

  @property({
    type: 'string',
    required: true,
  })
  telefone: string;

  @property({
    type: 'string',
    required: true,
  })
  email: string;

  @property({
    type: 'string',
    required: true,
  })
  empresa: string;


  constructor(data?: Partial<Fornecedores>) {
    super(data);
  }
}

export interface FornecedoresRelations {
  // describe navigational properties here
}

export type FornecedoresWithRelations = Fornecedores & FornecedoresRelations;
