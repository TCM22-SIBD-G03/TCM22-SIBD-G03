import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {G03DataSource} from '../datasources';
import {Produtos, ProdutosRelations} from '../models';

export class ProdutosRepository extends DefaultCrudRepository<
  Produtos,
  typeof Produtos.prototype.produto_id,
  ProdutosRelations
> {
  constructor(
    @inject('datasources.g03') dataSource: G03DataSource,
  ) {
    super(Produtos, dataSource);
  }
}
