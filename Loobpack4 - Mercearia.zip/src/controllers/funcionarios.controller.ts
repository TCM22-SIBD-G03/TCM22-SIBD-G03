import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {Funcionarios} from '../models';
import {FuncionariosRepository} from '../repositories';

export class FuncionariosController {
  constructor(
    @repository(FuncionariosRepository)
    public funcionariosRepository : FuncionariosRepository,
  ) {}

  @post('/funcionarios')
  @response(200, {
    description: 'Funcionarios model instance',
    content: {'application/json': {schema: getModelSchemaRef(Funcionarios)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Funcionarios, {
            title: 'NewFuncionarios',
            exclude: ['id'],
          }),
        },
      },
    })
    funcionarios: Omit<Funcionarios, 'id'>,
  ): Promise<Funcionarios> {
    return this.funcionariosRepository.create(funcionarios);
  }

  @get('/funcionarios/count')
  @response(200, {
    description: 'Funcionarios model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Funcionarios) where?: Where<Funcionarios>,
  ): Promise<Count> {
    return this.funcionariosRepository.count(where);
  }

  @get('/funcionarios')
  @response(200, {
    description: 'Array of Funcionarios model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Funcionarios, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Funcionarios) filter?: Filter<Funcionarios>,
  ): Promise<Funcionarios[]> {
    return this.funcionariosRepository.find(filter);
  }

  @patch('/funcionarios')
  @response(200, {
    description: 'Funcionarios PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Funcionarios, {partial: true}),
        },
      },
    })
    funcionarios: Funcionarios,
    @param.where(Funcionarios) where?: Where<Funcionarios>,
  ): Promise<Count> {
    return this.funcionariosRepository.updateAll(funcionarios, where);
  }

  @get('/funcionarios/{id}')
  @response(200, {
    description: 'Funcionarios model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Funcionarios, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Funcionarios, {exclude: 'where'}) filter?: FilterExcludingWhere<Funcionarios>
  ): Promise<Funcionarios> {
    return this.funcionariosRepository.findById(id, filter);
  }

  @patch('/funcionarios/{id}')
  @response(204, {
    description: 'Funcionarios PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Funcionarios, {partial: true}),
        },
      },
    })
    funcionarios: Funcionarios,
  ): Promise<void> {
    await this.funcionariosRepository.updateById(id, funcionarios);
  }

  @put('/funcionarios/{id}')
  @response(204, {
    description: 'Funcionarios PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() funcionarios: Funcionarios,
  ): Promise<void> {
    await this.funcionariosRepository.replaceById(id, funcionarios);
  }

  @del('/funcionarios/{id}')
  @response(204, {
    description: 'Funcionarios DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.funcionariosRepository.deleteById(id);
  }
}
