import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {Seccao} from '../models';
import {SeccaoRepository} from '../repositories';

export class SeccaoController {
  constructor(
    @repository(SeccaoRepository)
    public seccaoRepository : SeccaoRepository,
  ) {}

  @post('/seccaos')
  @response(200, {
    description: 'Seccao model instance',
    content: {'application/json': {schema: getModelSchemaRef(Seccao)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Seccao, {
            title: 'NewSeccao',
            exclude: ['id'],
          }),
        },
      },
    })
    seccao: Omit<Seccao, 'id'>,
  ): Promise<Seccao> {
    return this.seccaoRepository.create(seccao);
  }

  @get('/seccaos/count')
  @response(200, {
    description: 'Seccao model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Seccao) where?: Where<Seccao>,
  ): Promise<Count> {
    return this.seccaoRepository.count(where);
  }

  @get('/seccaos')
  @response(200, {
    description: 'Array of Seccao model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Seccao, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Seccao) filter?: Filter<Seccao>,
  ): Promise<Seccao[]> {
    return this.seccaoRepository.find(filter);
  }

  @patch('/seccaos')
  @response(200, {
    description: 'Seccao PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Seccao, {partial: true}),
        },
      },
    })
    seccao: Seccao,
    @param.where(Seccao) where?: Where<Seccao>,
  ): Promise<Count> {
    return this.seccaoRepository.updateAll(seccao, where);
  }

  @get('/seccaos/{id}')
  @response(200, {
    description: 'Seccao model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Seccao, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Seccao, {exclude: 'where'}) filter?: FilterExcludingWhere<Seccao>
  ): Promise<Seccao> {
    return this.seccaoRepository.findById(id, filter);
  }

  @patch('/seccaos/{id}')
  @response(204, {
    description: 'Seccao PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Seccao, {partial: true}),
        },
      },
    })
    seccao: Seccao,
  ): Promise<void> {
    await this.seccaoRepository.updateById(id, seccao);
  }

  @put('/seccaos/{id}')
  @response(204, {
    description: 'Seccao PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() seccao: Seccao,
  ): Promise<void> {
    await this.seccaoRepository.replaceById(id, seccao);
  }

  @del('/seccaos/{id}')
  @response(204, {
    description: 'Seccao DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.seccaoRepository.deleteById(id);
  }
}
