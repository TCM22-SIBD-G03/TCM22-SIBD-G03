import {Entity, model, property} from '@loopback/repository';

@model()
export class Funcionarios extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
    required: true,
  })
  nome: string;

  @property({
    type: 'string',
    required: true,
  })
  cargo: string;

  @property({
    type: 'date',
    required: true,
  })
  data_contratacao: string;

  @property({
    type: 'number',
    required: true,
  })
  salario: number;

  @property({
    type: 'number',
    required: true,
  })
  departamento_id: number;


  constructor(data?: Partial<Funcionarios>) {
    super(data);
  }
}

export interface FuncionariosRelations {
  // describe navigational properties here
}

export type FuncionariosWithRelations = Funcionarios & FuncionariosRelations;
