import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {G03DataSource} from '../datasources';
import {Despesa, DespesaRelations} from '../models';

export class DespesaRepository extends DefaultCrudRepository<
  Despesa,
  typeof Despesa.prototype.id,
  DespesaRelations
> {
  constructor(
    @inject('datasources.g03') dataSource: G03DataSource,
  ) {
    super(Despesa, dataSource);
  }
}
