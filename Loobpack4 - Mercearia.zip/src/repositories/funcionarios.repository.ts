import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {G03DataSource} from '../datasources';
import {Funcionarios, FuncionariosRelations} from '../models';

export class FuncionariosRepository extends DefaultCrudRepository<
  Funcionarios,
  typeof Funcionarios.prototype.id,
  FuncionariosRelations
> {
  constructor(
    @inject('datasources.g03') dataSource: G03DataSource,
  ) {
    super(Funcionarios, dataSource);
  }
}
