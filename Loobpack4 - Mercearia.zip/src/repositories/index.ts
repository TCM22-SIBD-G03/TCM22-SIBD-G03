export * from './clientes.repository';
export * from './despesa.repository';
export * from './estoque.repository';
export * from './formacao.repository';
export * from './fornecedores.repository';
export * from './funcionarios.repository';
export * from './produtos.repository';
export * from './seccao.repository';
