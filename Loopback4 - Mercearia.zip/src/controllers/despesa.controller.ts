import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {Despesa} from '../models';
import {DespesaRepository} from '../repositories';

export class DespesaController {
  constructor(
    @repository(DespesaRepository)
    public despesaRepository : DespesaRepository,
  ) {}

  @post('/despesas')
  @response(200, {
    description: 'Despesa model instance',
    content: {'application/json': {schema: getModelSchemaRef(Despesa)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Despesa, {
            title: 'NewDespesa',
            exclude: ['id'],
          }),
        },
      },
    })
    despesa: Omit<Despesa, 'id'>,
  ): Promise<Despesa> {
    return this.despesaRepository.create(despesa);
  }

  @get('/despesas/count')
  @response(200, {
    description: 'Despesa model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Despesa) where?: Where<Despesa>,
  ): Promise<Count> {
    return this.despesaRepository.count(where);
  }

  @get('/despesas')
  @response(200, {
    description: 'Array of Despesa model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Despesa, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Despesa) filter?: Filter<Despesa>,
  ): Promise<Despesa[]> {
    return this.despesaRepository.find(filter);
  }

  @patch('/despesas')
  @response(200, {
    description: 'Despesa PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Despesa, {partial: true}),
        },
      },
    })
    despesa: Despesa,
    @param.where(Despesa) where?: Where<Despesa>,
  ): Promise<Count> {
    return this.despesaRepository.updateAll(despesa, where);
  }

  @get('/despesas/{id}')
  @response(200, {
    description: 'Despesa model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Despesa, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Despesa, {exclude: 'where'}) filter?: FilterExcludingWhere<Despesa>
  ): Promise<Despesa> {
    return this.despesaRepository.findById(id, filter);
  }

  @patch('/despesas/{id}')
  @response(204, {
    description: 'Despesa PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Despesa, {partial: true}),
        },
      },
    })
    despesa: Despesa,
  ): Promise<void> {
    await this.despesaRepository.updateById(id, despesa);
  }

  @put('/despesas/{id}')
  @response(204, {
    description: 'Despesa PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() despesa: Despesa,
  ): Promise<void> {
    await this.despesaRepository.replaceById(id, despesa);
  }

  @del('/despesas/{id}')
  @response(204, {
    description: 'Despesa DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.despesaRepository.deleteById(id);
  }
}
