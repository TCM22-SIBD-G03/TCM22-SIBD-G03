import {Entity, model, property} from '@loopback/repository';

@model()
export class Clientes extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  idcliente?: number;

  @property({
    type: 'string',
    required: true,
  })
  nome: string;

  @property({
    type: 'string',
    required: true,
  })
  email: string;

  @property({
    type: 'string',
    required: true,
  })
  telefone: string;

  @property({
    type: 'string',
    required: true,
  })
  morada: string;

  @property({
    type: 'number',
    required: true,
  })
  idade: number;

  @property({
    type: 'string',
    required: true,
  })
  NIF: string;

  @property({
    type: 'number',
    required: true,
  })
  despesa: number;


  constructor(data?: Partial<Clientes>) {
    super(data);
  }
}

export interface ClientesRelations {
  // describe navigational properties here
}

export type ClientesWithRelations = Clientes & ClientesRelations;
