import {Entity, model, property} from '@loopback/repository';

@model()
export class Seccao extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
    required: true,
  })
  nome: string;

  @property({
    type: 'string',
    required: true,
  })
  descricao: string;

  @property({
    type: 'number',
    required: true,
  })
  gerente_id: number;


  constructor(data?: Partial<Seccao>) {
    super(data);
  }
}

export interface SeccaoRelations {
  // describe navigational properties here
}

export type SeccaoWithRelations = Seccao & SeccaoRelations;
