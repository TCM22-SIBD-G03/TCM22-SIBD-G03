import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {G03DataSource} from '../datasources';
import {Fornecedores, FornecedoresRelations} from '../models';

export class FornecedoresRepository extends DefaultCrudRepository<
  Fornecedores,
  typeof Fornecedores.prototype.id,
  FornecedoresRelations
> {
  constructor(
    @inject('datasources.g03') dataSource: G03DataSource,
  ) {
    super(Fornecedores, dataSource);
  }
}
