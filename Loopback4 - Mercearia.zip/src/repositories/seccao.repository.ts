import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {G03DataSource} from '../datasources';
import {Seccao, SeccaoRelations} from '../models';

export class SeccaoRepository extends DefaultCrudRepository<
  Seccao,
  typeof Seccao.prototype.id,
  SeccaoRelations
> {
  constructor(
    @inject('datasources.g03') dataSource: G03DataSource,
  ) {
    super(Seccao, dataSource);
  }
}
