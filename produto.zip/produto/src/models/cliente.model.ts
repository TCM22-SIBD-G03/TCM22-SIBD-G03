import {Entity, model, property} from '@loopback/repository';

@model()
export class Cliente extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  idcliente?: number;

  @property({
    type: 'string',
    required: true,
  })
  nome: string;

  @property({
    type: 'string',
    required: true,
  })
  email: string;

  @property({
    type: 'number',
    required: true,
  })
  telefone: number;

  @property({
    type: 'number',
    required: true,
  })
  morada: number;

  @property({
    type: 'number',
    required: true,
  })
  idade: number;

  @property({
    type: 'number',
    required: true,
  })
  nif: number;

  @property({
    type: 'number',
    required: true,
  })
  despesa: number;


  constructor(data?: Partial<Cliente>) {
    super(data);
  }
}

export interface ClienteRelations {
  // describe navigational properties here
}

export type ClienteWithRelations = Cliente & ClienteRelations;
