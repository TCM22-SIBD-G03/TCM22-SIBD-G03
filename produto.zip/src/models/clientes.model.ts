import {Entity, model, property} from '@loopback/repository';

@model()
export class clientes extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  idcliente?: number;

  @property({
    type: 'string',
    required: true,
  })
  nome: string;

  @property({
    type: 'string',
    required: true,
  })
  email: string;

  @property({
    type: 'number',
    required: true,
  })
  telefone: number;

  @property({
    type: 'number',
    required: true,
  })
  morada: number;

  @property({
    type: 'number',
    required: true,
  })
  idade: number;

  @property({
    type: 'number',
    required: true,
  })
  NIF: number;

  @property({
    type: 'number',
    required: true,
  })
  despesa: number;


  constructor(data?: Partial<clientes>) {
    super(data);
  }
}

export interface ClientesRelations {
  // describe navigational properties here
}

export type clientesWithRelations = Clientes & ClientesRelations;
