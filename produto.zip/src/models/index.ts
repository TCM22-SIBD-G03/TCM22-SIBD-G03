export * from './clientes.model';
export * from './despesa.model';
export * from './estoque.model';
export * from './formação.model';
export * from './fornecedores.model';
export * from './funcionários.model';
export * from './produtos.model';
export * from './seccao.model';
